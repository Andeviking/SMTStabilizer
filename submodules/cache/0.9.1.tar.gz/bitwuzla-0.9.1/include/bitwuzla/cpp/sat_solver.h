/***
 * Bitwuzla: Satisfiability Modulo Theories (SMT) solver.
 *
 * Copyright (C) 2022 by the authors listed in the AUTHORS file at
 * https://github.com/bitwuzla/bitwuzla/blob/main/AUTHORS
 *
 * This file is part of Bitwuzla under the MIT license. See COPYING for more
 * information at https://github.com/bitwuzla/bitwuzla/blob/main/COPYING
 */

#ifndef BITWUZLA_API_CPP_SAT_SOLVER_H_INCLUDED
#define BITWUZLA_API_CPP_SAT_SOLVER_H_INCLUDED

#include <bitwuzla/cpp/terminator.h>
#include <bitwuzla/result.h>

#include <cstdint>

namespace bitwuzla {

/**
 * The SAT solver interface.
 * @warning This interface is experimental and may change in future versions.
 */
class SatSolver
{
 public:
  /** Constructor. */
  SatSolver() {}
  /** Destructor. */
  virtual ~SatSolver() {};

  /**
   * Add valid literal to current clause.
   * @param lit       The literal to add, 0 to terminate clause..
   * @param cgroup_id The "clause group" id, associates a clause with a
   *                  clause group. This is only relevant for interpolation
   *                  where this labeling allows for mapping back clauses to
   *                  the corresponding nodes in the bit-level circuit.
   *                  It can be left at its default value, otherwise.
   */
  virtual void add(int32_t lit, int64_t cgroup_id = 0) = 0;
  /**
   * Assume valid (non-zero) literal for next call to 'check_sat'.
   * @param lit The literal to assume.
   */
  virtual void assume(int32_t lit) = 0;
  /**
   * Get value of valid non-zero literal.
   * @param lit The literal to query.
   * @return The value of the literal (-1 = false, 1 = true, 0 = unknown).
   */
  virtual int32_t value(int32_t lit) = 0;
  /**
   * Determine if the valid non-zero literal is in the unsat core.
   * @param lit The literal to query.
   * @return True if the literal is in the core, and false otherwise.
   */
  virtual bool failed(int32_t lit) = 0;
  /**
   * Determine if the given literal is implied by the formula.
   * @return 1 if it is implied, -1 if it is not implied and 0 if unknown.
   */
  virtual int32_t fixed(int32_t lit) = 0;
  /**
   * Check satisfiability of current formula.
   * @return The result of the satisfiability check.
   */
  virtual Result solve() = 0;
  /**
   * Configure a termination callback function via a terminator.
   * @param terminator The terminator.
   */
  virtual void configure_terminator(Terminator* terminator) = 0;

  /**
   * Get the name of this SAT solver.
   * @return The name of this SAT solver.
   */
  virtual const char* get_name() const = 0;

  /**
   * Get the version of this SAT solver.
   * @return The version of the underly ing SAT solver.
   */
  virtual const char* get_version() const = 0;
};

}  // namespace bitwuzla
#endif

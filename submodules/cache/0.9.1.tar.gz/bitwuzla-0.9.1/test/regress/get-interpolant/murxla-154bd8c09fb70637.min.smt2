; ignore output
(set-option :produce-interpolants 1)
(declare-const x Bool)
(declare-const x1 Bool)
(assert (distinct true (or x x1 (not (= x (not x1))))))
(assert (! x1 :named a2))
(set-info :status unsat)
(check-sat)
(get-interpolant (a2))

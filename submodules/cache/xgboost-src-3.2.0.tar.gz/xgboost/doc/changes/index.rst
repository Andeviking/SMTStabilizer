#############
Release Notes
#############

For release notes prior to the 2.1 release, please see `news <https://github.com/dmlc/xgboost/blob/master/NEWS.md>`__ .

.. toctree::
  :maxdepth: 1
  :caption: Contents:

  v3.2.0
  v3.1.0
  v3.0.0
  v2.1.0
